# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['adtoolbox']

package_data = \
{'': ['*'], 'adtoolbox': ['pkg_data/*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'dash>=2.4.1,<3.0.0',
 'numpy>=1.22.4,<2.0.0',
 'pandas>=1.4.2,<2.0.0',
 'plotly>=5.8.0,<6.0.0',
 'requests>=2.27.1,<3.0.0',
 'rich>=12.4.4,<13.0.0',
 'scipy>=1.8.1,<2.0.0',
 'sympy>=1.10.1,<2.0.0']

entry_points = \
{'console_scripts': ['ADToolbox = adtoolbox.__main__:main']}

setup_kwargs = {
    'name': 'adtoolbox',
    'version': '0.1.0',
    'description': 'A tool for modeling and optimization of anaerobic digestion process.',
    'long_description': "# Toolbox Overview\n\nParsa Ghadermazi \nparsa96@colostate.edu\n\nAD Toolbox is developed in Chan Lab at Colorado State University. The main goal of this toolbox is to provide the tools that are useful for modeling and optimization of anaerobic digestion process. \n\n## Installation\n\nAlthough it is not mandatory, It is greatly advised to create a python environment for this project and install ADToolbox in that environment. Check for how to build and use python's virtual environments. There are severall methods that allow you to install or use ADToolbox:\n\n\n1- Install by cloning this repository:\n\n```\ngit clone https://github.com/chan-csu/ADToolbox.git\ncd ADToolbox\npip install -e .\n\n```\n2- Install using pip\n\n```\nNot available yet\n\n```\n\n3- Use docker\n\n```\nNot available yet\n\n```\n\n4- Click bellow:\n\n```\nMy binder place holder \n\n```\n-------------------\n# Using ADToolbox\n\nAfter installing ADToolbox, type and execute the following in your terminal to initialize the base directory for ADToolbox files:\n\n```\nADToolbox\n\n```\nYou should see the following if you are running this for the first time:\n\n```\nNo Base Directory Found: \nWhere do you want to store your ADToolBox Data?:\n\n```\ntype the directory of interest. Don't worry if you mess this part up. You can change this later as well.\n\nThis Toolbox is comprised of different modules:\n\n1. Database Module\n\n2. Metagenomics Module\n\n3. Documentations Module\n\n4. ADM Module\n\n5. Report Module\n\n6. Utility Module\n\n7. Configs Module\n\n---------------------------------------------------\n\n## 1- Database Module\n\n-------------\n\n\nDatabase module handles any task that is related to the ADToolbox. In order to find out what functions this module provides, type the following in your terminal **after installation**:\n\n```\npython ADToolbox Database --help\n\n```\n\nthis will print the following in the console:\n\n```\noptional arguments:\n  -h, --help            show this help message and exit\n  --Initialize-Feed-DB  Initialize the Feed DB\n  --Extend-Feed-DB EXTEND_FEED_DB\n                        Extend the Feed Database using a CSV file\n  --Show-Feed-DB        Display the Current Feed Database\n  --Show-Reaction-DB    Display the Current Compound Database\n  --Build-Protein-DB    Generates the protein database for ADToolbox\n\n```\n",
    'author': 'ParsaGhadermazi',
    'author_email': '54489047+ParsaGhadermazi@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<3.11',
}


setup(**setup_kwargs)
