import sys
import os
from cli import main as main
import adtoolbox

if __name__ == '__main__':
    main()